﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Telerik.Sitefinity.Fluent.AnyContent.Implementation;
using Telerik.Sitefinity.Services;
using Telerik.Sitefinity.Services.Notifications;
using Telerik.Sitefinity.Versioning.Comparison;
using Telerik.Sitefinity.Workflow.Activities;
using Telerik.Sitefinity.Workflow.Model;

namespace Telerik.Sitefinity.Samples.Workflow
{
    public class CustomNotifyGroup : NotifyGroup
    {
         List<string> emailList = new List<string>();
         string messageBody = null;
    
         protected override void Execute(CodeActivityContext context)
         {
             try
             {
                 OnExcecuting(context);
                 var dataContext = context.DataContext;
                 var workflowDefinition = (WorkflowDefinition)dataContext.GetProperties()["workflowDefinition"].GetValue(dataContext);
                 if (workflowDefinition != null)
                 {
                     if (workflowDefinition.WorkflowType == WorkflowType.StandardOneStep && !workflowDefinition.SendFirstLevelEmailNotification)
                     {
    
                         return;
                     }
    
                     if (workflowDefinition.WorkflowType == WorkflowType.StandardTwoStep)
                     {
                         var approvalState = (((AnyDraftFacade)(dataContext.GetProperties()["masterFluent"].GetValue(dataContext))).Get() as IApprovalWorkflowItem).ApprovalWorkflowState;
    
                         if (approvalState == "AwaitingPublishing" && !workflowDefinition.SendSecondLevelEmailNotification)
                             return;
    
                         if (approvalState == "AwaitingApproval" && !workflowDefinition.SendFirstLevelEmailNotification)
                             return;
                     }
                 }
    
                 //get the item sent through workflow
                 var masterFluent = dataContext.GetProperties()["masterFluent"].GetValue(dataContext) as AnyDraftFacade;
                 //check if it has an already published version
                 var live = masterFluent.GetLiveIfExists();
                 emailList = GetEmails(context);
    
                 //if there is published version construct the comparison
                 if (live != null)
                 {
                     StringBuilder sb = new StringBuilder();
                     //use ContentComparator to compare two versions of the same item. The class returns a comparison of each property
                     ContentComparator contentComparator = new ContentComparator();
                     contentComparator.Settings.DateTimeDisplayFormat = "dd MMM, yyyy; hh:mm tt";
                     //get only different results
                     var compareResults = contentComparator.Compare(live.Get(), masterFluent.Get()).Where(cR => cR.AreDifferent == true);
                     sb.Append("<table>");
                     //construct comparison table with styling
                     foreach (var result in compareResults)
                     {
                         string diffHTML = result.DiffHtml;
                         if (diffHTML.Contains("class='diff_new'"))
                             diffHTML = diffHTML.Replace("class='diff_new'", "style='color: #008000; text-decoration: underline;'");
                         if (diffHTML.Contains("class='diff_deleted'"))
                             diffHTML = diffHTML.Replace("class='diff_deleted'", "style='color: #FF0000; text-decoration: line-through;'");
                         if (diffHTML.Contains("class=\"diff_new\""))
                             diffHTML = diffHTML.Replace("class=\"diff_new\"", "style='color: #008000; text-decoration: underline;'");
                         if (diffHTML.Contains("class=\"diff_deleted\""))
                             diffHTML = diffHTML.Replace("class=\"diff_deleted\"", "style='color: #FF0000; text-decoration: line-through;'");
                         sb.AppendFormat(@"<tr>
                                               <td style='font-size: 13px; font-weight: bold; line-height: 1.1; width: 100px;'>{0}</td>
                                               <td style='font-size: 11px; margin-left: 20px; overflow: hidden; width: 375px;'>{1}</td>
                                               <td style='font-size: 11px; margin-left: 20px; overflow: hidden; width: 375px; '>{2}</td>
                                            </tr>", result.PropertyName, result.OldValue, diffHTML);
                     }
                     sb.Append("</table>");
                     //add the table to the original message body
                     messageBody += sb.ToString();
                 }
                 //uses the notification service to send a message
                 SendMessage();
             }
             catch (Exception ex)
             { }
         }
    
         public void SendMessage()
         {
             var serviceContext = new Telerik.Sitefinity.Services.Notifications.ServiceContext(null, null);
             var messageTemplate = new Telerik.Sitefinity.Services.Notifications.MessageTemplateRequestProxy() { Subject = "Subject", BodyHtml = messageBody };
             var messageJob = new Telerik.Sitefinity.Services.Notifications.MessageJobRequestProxy()
             {
                 Description = "Sending message through workflow",
                 MessageTemplate = messageTemplate,
                 Subscribers = new List<SubscriberRequestProxy>()
                         {
                             new SubscriberRequestProxy()
                             {
                                 Email = emailList[0],
                                 ResolveKey = Guid.NewGuid().ToString()
                             }
                         },
             };
             SystemManager.GetNotificationService().SendMessage(serviceContext, messageJob, null);
         }
     }
}
